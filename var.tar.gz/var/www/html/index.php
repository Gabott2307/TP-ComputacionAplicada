 <?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "Script iniciado<br>";

$servername = "localhost";
$port = "3306";
$username = "lcars";
$password = "NCC1701D";
$dbname = "ingenieria";

$conn = new MySQLi($servername, $username, $password, $dbname, $port);

// Error de conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$sql = "SELECT 
            alumnos.legajo AS legajo, 
            alumnos.apellido AS apellido, 
            alumnos.nombres AS nombre,
            modulos.nom_modulo AS materia, 
            notas.nota AS nota
        FROM alumnos
        JOIN notas ON alumnos.legajo = notas.legajo
        JOIN modulos ON modulos.cod_modulo = notas.cod_modulo";

$result = $conn->query($sql);

if (!$result) {
    die("Error en la consulta: " . $conn->error);
}

// Crear una tabla HTML para mostrar los datos
echo '<!DOCTYPE html>';
echo '<html>';
echo '<head>';
echo '<title>Datos de Alumnos</title>';
echo '<style>';
echo 'body { font-family: Arial, sans-serif; margin: 20px; }';
echo 'table { width: 100%; border-collapse: collapse; }';
echo 'th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }';
echo 'tr:nth-child(even) { background-color: #f2f2f2; }';
echo 'th { background-color: #4CAF50; color: white; }';
echo '.header { display: flex; align-items: center; margin-bottom: 20px; }';
echo '.header img { height: 50px; margin-right: 15px; }';
echo '.header h1 { margin: 0; }';
echo '</style>';
echo '</head>';
echo '<body>';
echo '<div class="header">';
echo '<img src="./logo.png" alt="Logo">';
echo '<h1>Datos de Alumnos</h1>';
echo '</div>';

if ($result->num_rows > 0) {
    echo '<table>';
    echo '<tr><th>Legajo</th><th>Apellido</th><th>Nombre</th><th>Materia</th><th>Nota</th></tr>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row["legajo"]) . '</td>';
        echo '<td>' . htmlspecialchars($row["apellido"]) . '</td>';
        echo '<td>' . htmlspecialchars($row["nombre"]) . '</td>';
        echo '<td>' . htmlspecialchars($row["materia"]) . '</td>';
        echo '<td>' . htmlspecialchars($row["nota"]) . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo '0 resultados';
}

echo '</body>';
echo '</html>';

$conn->close();

?>
