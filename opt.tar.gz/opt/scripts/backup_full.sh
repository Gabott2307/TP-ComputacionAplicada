#!/bin/bash

# backup_full.sh - Script para realizar backups con nombre por fecha

# Función de ayuda
function mostrar_ayuda {
    echo "Uso: $0 -origen <directorio_origen> -destino <directorio_destino>"
    echo "Ejemplo: $0 -origen /var/log -destino /backup_dir"
    exit 1
}

# Verificar si se pasó la opción -help o argumentos inválidos
if [[ "$1" == "-help" || $# -ne 4 ]]; then
    mostrar_ayuda
fi

# Leer argumentos del usuario
while [[ $# -gt 0 ]]; do
    case "$1" in
        -origen)
            ORIGEN="$2"
            shift 2
            ;;
        -destino)
            DESTINO="$2"
            shift 2
            ;;
        *)
            mostrar_ayuda
            ;;
    esac
done

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen '$ORIGEN' no existe"
	exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio de destino '$DESTINO' no existe"
	exit 3
fi

NOMBRE_DIR=$(basename "$ORIGEN")
FECHA=$(date +%m-%d-%Y)
ARCHIVO="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"
tar -czf "${DESTINO}/${ARCHIVO}" -C "$(dirname "$ORIGEN")" "$NOMBRE_DIR"

echo "Backup creado exitosamente en: ${DESTINO}/${ARCHIVO}"
